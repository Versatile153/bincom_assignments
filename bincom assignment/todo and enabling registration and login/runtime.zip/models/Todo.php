<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "todu".
 *
 * @property int $id
 * @property string $title
 * @property string $description
 */
class Todo extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'todu';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['title', 'description','author'], 'required'],
            [['title', 'description','author'], 'string', 'max' => 255],
            [['user_id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'description' => 'Description',
            'author' => 'Author',
            'user_id' => 'User ID',

        ];
    }

    // public function getUser()
    // {
    //     return $this->hasOne(User::class, ['id' => 'user_id']);
    // }
}
