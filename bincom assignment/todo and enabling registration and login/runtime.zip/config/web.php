<?php

$params = require __DIR__ . '/params.php';
$db = require __DIR__ . '/db.php';

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'aliases' => [
        '@bower' => '@vendor/bower-asset',
        '@npm'   => '@vendor/npm-asset',
    ],
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => '47Hm2v_GqQR43CcDFvFuDFrcGftNFo9i',
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'user' => [
            'identityClass' => 'app\models\User',
            'enableAutoLogin' => true,
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'mailer' => [
            'class' => \yii\symfonymailer\Mailer::class,
            'viewPath' => '@app/mail',
            // send all mails to a file by default.
            'useFileTransport' => true,
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'db' => $db,

        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                // Add the rule for the BlogsController
                'blogs' => 'blogs/index', // Map '/blogs' to the 'index' action of 'BlogsController'
                'blogs/create' => 'blogs/create', // Map '/blogs/create' to the 'create' action of 'BlogsController'
                'blogs/view/<id:\d+>' => 'blogs/view', // Map '/blogs/view/123' to the 'view' action of 'BlogsController'
                'blogs/update/<id:\d+>' => 'blogs/update', // Map '/blogs/update/123' to the 'update' action of 'BlogsController'
                'blogs/delete/<id:\d+>' => 'blogs/delete',
                'register' => 'site/register',

                 // Map '/blogs/delete/123' to the 'delete' action of 'BlogsController'
            ],
        ],
    ],
    'params' => $params,
];

// The rest of the configuration remains the same
// ...

return $config;
