<?php

namespace app\controllers;

use app\models\AvailableCourse;
use Yii;
use yii\web\Controller;
use app\models\Course; // Assuming you have a Course model
use app\models\Register;
use yii\data\Pagination;
use yii\filters\AccessControl;

// use CourseRegistrationForm as GlobalCourseRegistrationForm;

class CourseRegistrationController extends Controller
{




 

    // ...
    
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['register', 'register-selected', 'success'], // Actions to protect
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // '@' represents logged-in users
                    ],
                ],
            ],
            // Other behaviors...
        ];
    }
    




    public function actionIndex()
{
    $query = AvailableCourse::find();

    // Create a pagination object and set the page size (number of items per page)
    $pagination = new Pagination([
        'defaultPageSize' => 10, // Set the number of items per page here (e.g., 10)
        'totalCount' => $query->count(),
    ]);

    // Limit the query results based on the pagination
    $courses = $query->orderBy('id')
        ->offset($pagination->offset)
        ->limit($pagination->limit)
        ->all();

    return $this->render('index', [
        'courses' => $courses,
        'pagination' => $pagination, // Pass the pagination object to the view
    ]);
}


    public function actionRegister()
    {
        $model = new Course(); // Assuming you have a CourseRegistrationForm model
    
        // Fetch the course options from the Course model and use 'course_id' as the value
        $courseList = AvailableCourse::find()->select(['course_name', 'course_name'])->indexBy('id')->column();
    
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            // Save registration data to the database or take appropriate actions
            // Redirect to a success page or show a success message
            return $this->redirect(['index']);
        }
    
        return $this->render('register', [
            'model' => $model,
            'courseList' => $courseList,
        ]);
    }
    


    public function actionSuccess()
    {
        // Display a success message after successful course registration
        return $this->render('success');
    }


    public function actionRegisterSelected()
{
    // Get the IDs of the selected courses from the request
    $selectedCourseIds = Yii::$app->request->post('selection');

    // Assuming you have a registration process in place, 
    // save the selected course IDs for the currently logged-in student to the database

    // Redirect to a success page or show a success message
    return $this->redirect(['success']);
}
}
