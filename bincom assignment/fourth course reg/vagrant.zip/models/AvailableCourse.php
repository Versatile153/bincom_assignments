<?php

namespace app\models;

use Yii;

class AvailableCourse extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'available_courses';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['course_name', 'course_code'], 'required'],
            [['course_name', 'course_code'], 'string', 'max' => 255],
            // Add other validation rules as needed
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'course_name' => 'Course Name',
            'course_code' => 'Course Code',
            // Add other attribute labels as needed
        ];
    }
}
