<!-- views/course-registration/index.php -->

<h1>List of Available Courses</h1>

<?= yii\grid\GridView::widget([
    'dataProvider' => new yii\data\ArrayDataProvider([
        'allModels' => $courses,
    ]),
    'columns' => [
        [
            'class' => 'yii\grid\CheckboxColumn', // Checkbox column for course selection
            'checkboxOptions' => function ($model, $key, $index, $column) {
                return ['value' => $model->id, 'onclick' => 'disableOtherCheckboxes(this);'];
            },
        ],
        'course_name',
        'course_code',
        // Add more columns as needed
    ],
]) ?>

<div>
    <?= \yii\helpers\Html::a('Register Selected Courses', ['register-selected'], ['class' => 'btn btn-primary', 'onclick' => 'submitForm();']) ?>
</div>

<?= yii\widgets\LinkPager::widget(['pagination' => $pagination]) ?>

<!-- JavaScript to handle checkbox behavior and form submission -->
<script>
    function disableOtherCheckboxes(checkbox) {
        var checkboxes = document.querySelectorAll('input[type="checkbox"]');
        checkboxes.forEach(function (cb) {
            if (cb !== checkbox) {
                cb.disabled = checkbox.checked;
            }
        });
    }

    function submitForm() {
        var selectedCourseId = getSelectedCourseId();
        if (selectedCourseId) {
            // Submit the form with the selected course ID
            var form = document.createElement('form');
            form.method = 'POST';
            form.action = '<?= \yii\helpers\Url::to(['register-selected']) ?>'; // Replace with the correct URL
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'selectedCourseId';
            input.value = selectedCourseId;
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        } else {
            alert('Please select a course to register.');
        }
    }

    function getSelectedCourseId() {
        var checkboxes = document.querySelectorAll('input[type="checkbox"]');
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].checked) {
                return checkboxes[i].value;
            }
        }
        return null;
    }
</script>
