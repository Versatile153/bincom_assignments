<!-- views/course-registration/success.php -->

<h1>Course Registration Successful!</h1>

<p>Thank you for registering for the course. You will receive further instructions via email.</p>
