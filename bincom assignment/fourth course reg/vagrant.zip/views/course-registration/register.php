<!-- views/course-registration/register.php -->

<h1>Course Add Form</h1>

<?php $form = yii\widgets\ActiveForm::begin([
    'id' => 'course-registration-form',
    'options' => ['class' => 'form-horizontal'],
]) ?>

<?= $form->field($model, 'course_name')->textInput(['maxlength' => true]) ?>

<!-- <?= $form->field($model, 'course_name')->dropDownList($courseList, ['prompt' => 'Select a course']) ?> -->
<?= $form->field($model, 'course_code')->textInput(['maxlength' => true]) ?>

<div class="form-group">
    <div class="col-lg-offset-1 col-lg-11">
        <?= yii\helpers\Html::submitButton('Add Course', ['class' => 'btn btn-primary']) ?>
    </div>
</div>

<?php yii\widgets\ActiveForm::end() ?>
