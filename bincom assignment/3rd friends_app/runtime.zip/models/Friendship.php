<?php
namespace app\models;

use yii\db\ActiveRecord;

class Friendship extends ActiveRecord
{
    const STATUS_REQUESTED = 0;
    const STATUS_ACCEPTED = 1;

    public $recipientId; // Ad
    
    public static function tableName()
    {
        return 'friendships';
    }

    // Define any other relevant properties, validations, and behaviors.

    // Define relationship methods to get the users involved in the friendship.
    public function getUser1()
    {
        return $this->hasOne(User::class, ['id' => 'user_id1']);
    }

    public function getUser2()
    {
        return $this->hasOne(User::class, ['id' => 'user_id2']);
    }
}
