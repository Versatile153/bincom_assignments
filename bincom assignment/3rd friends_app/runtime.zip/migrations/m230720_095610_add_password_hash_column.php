<?php

use yii\db\Migration;

/**
 * Class m230720_095610_add_password_hash_column
 */
class m230720_095610_add_password_hash_column extends Migration
{
    public function safeUp()
    {
        $this->addColumn('{{%users}}', 'password_hash', $this->string()->notNull());
    }

    public function safeDown()
    {
        $this->dropColumn('{{%users}}', 'password_hash');
    }
    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m230720_095610_add_password_hash_column cannot be reverted.\n";

        return false;
    }
    */
}
