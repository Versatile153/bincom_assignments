<?php

$params = require __DIR__ . '/params.php';
$db = require __DIR__ . '/db.php';

$config = [
    'id' => 'basic',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'aliases' => [
        '@bower' => '@vendor/bower-asset',
        '@npm'   => '@vendor/npm-asset',
    ],
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'tTiPPAvtX7PpoIJfvDCjQw6EICIngVux',
        ],
        'cache' => [
            'class' => 'yii\caching\FileCache',
        ],
        'user' => [
            'identityClass' => 'app\models\User',
            'enableAutoLogin' => true,
        ],
        'errorHandler' => [
            'errorAction' => 'site/error',
        ],
        'mailer' => [
            'class' => \yii\symfonymailer\Mailer::class,
            'viewPath' => '@app/mail',
            // send all mails to a file by default.
            'useFileTransport' => true,
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => 'yii\log\FileTarget',
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'db' => $db,
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                // Route for the homepage (SiteController::actionIndex)
                '/' => 'site/index',
                'home' => 'site/index', // Optionally, you can add a custom route for the homepage

                // Route for the login page (SiteController::actionLogin)
                'login' => 'site/login',

                // Route for the registration page (SiteController::actionRegister)
                'register' => 'site/register',

                // Route for the contact page (SiteController::actionContact)
                'contact' => 'site/contact',

                // Route for the about page (SiteController::actionAbout)
                'about' => 'site/about',

                // Route for the "View Friends" page (FriendsController::actionViewFriends)
                'friends' => 'friends/view-friends',
                'friends/send-friend-request/<recipientId:\d+>' => 'friends/send-friend-request',
                'friends/accept-friend-request/<requestId:\d+>' => 'friends/accept-friend-request',
                'friends/users' => 'friends/users',



                // Add other custom routes as needed

                // If you have user-specific routes, you can define them here as well
                // For example, if you have a user profile page:
                // 'profile/<id:\d+>' => 'user/profile', // Assuming you have a UserController with actionProfile
            ],
        ],

    
    ],
    'params' => $params,
];

if (YII_ENV_DEV) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][] = 'debug';
    $config['modules']['debug'] = [
        'class' => 'yii\debug\Module',
        // uncomment the following to add your IP if you are not connecting from localhost.
        //'allowedIPs' => ['127.0.0.1', '::1'],
    ];

    $config['bootstrap'][] = 'gii';
    $config['modules']['gii'] = [
        'class' => 'yii\gii\Module',
        // uncomment the following to add your IP if you are not connecting from localhost.
        //'allowedIPs' => ['127.0.0.1', '::1'],
    ];
}

return $config;
