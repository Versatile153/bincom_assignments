<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use app\models\Friendship;
use app\models\User;
use yii\web\NotFoundHttpException;

class FriendsController extends Controller
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['send-friend-request', 'accept-friend-request', 'view-friends'],
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'], // '@' means authenticated users
                    ],
                ],
            ],
        ];
    }


    public function actionSendFriendRequest($recipientId)
    {
        $currentUser = User::findOne(Yii::$app->user->id);
        $recipient = User::findOne($recipientId);
        $model = new Friendship();
        $model->recipientId = $recipient->id;
    
        if ($currentUser && $recipient) {
            // Check if the recipient is not the same as the current user
            if ($recipient->id !== $currentUser->id) {
                // Check if there is an existing friend request between the current user and the recipient
                $existingRequest = Friendship::find()
                    ->where(['user_id1' => $currentUser->id, 'user_id2' => $recipient->id])
                    ->orWhere(['user_id1' => $recipient->id, 'user_id2' => $currentUser->id])
                    ->one();
    
                if (!$existingRequest) {
                    $friendship = new Friendship();
                    $friendship->user_id1 = $currentUser->id;
                    $friendship->user_id2 = $recipient->id;
                    $friendship->status = Friendship::STATUS_REQUESTED;
                    $friendship->created_at = date('Y-m-d H:i:s');
                    $friendship->save();
    
                    Yii::$app->session->setFlash('success', 'Friend request sent successfully.');
                } else {
                    Yii::$app->session->setFlash('error', 'You have already sent a friend request to this user.');
                }
    
                // Redirect back to the same page
                return $this->redirect(Yii::$app->request->referrer);
            } else {
                // The user is trying to send a friend request to themselves
                Yii::$app->session->setFlash('error', 'You cannot send a friend request to yourself.');
            }
        }
    
        throw new \yii\web\NotFoundHttpException('User not found.');
    }
    
    
    public function actionAcceptFriendRequest($requestId)
{
    $friendship = Friendship::findOne($requestId);

    if ($friendship && $friendship->status === Friendship::STATUS_REQUESTED) {
        $friendship->status = Friendship::STATUS_ACCEPTED;
        $friendship->save();
    } else {
        throw new NotFoundHttpException('Friendship request not found.');
    }

    return $this->redirect(['view-friends']);
}
public function actionRejectAcceptedFriend($requestId)
{
    $friendship = Friendship::findOne($requestId);

    if ($friendship && $friendship->status === Friendship::STATUS_ACCEPTED) {
        $friendship->status = Friendship::STATUS_REQUESTED;
        $friendship->save();
    } else {
        throw new NotFoundHttpException('Friendship request not found.');
    }

    return $this->redirect(['view-friends']);
}
    public function actionViewFriends()
    {
        $currentUser = User::findOne(Yii::$app->user->id);
    
        // Fetch both accepted and pending friend requests for the current user
        $acceptedRequests = Friendship::find()
            ->where(['status' => Friendship::STATUS_ACCEPTED])
            ->andWhere(['user_id1' => $currentUser->id])
            ->orWhere(['user_id2' => $currentUser->id])
            ->all();
    
        $pendingRequests = Friendship::find()
            ->where(['status' => Friendship::STATUS_REQUESTED])
            ->andWhere(['user_id1' => $currentUser->id])
            ->all();
    
        return $this->render('views', [
            'acceptedRequests' => $acceptedRequests,
            'pendingRequests' => $pendingRequests,
        ]);
    }





    public function actionUsers()
{
    $users = User::find()->where(['not', ['id' => Yii::$app->user->id]])->all();

    return $this->render('users', [
        'users' => $users,
    ]);
}
    


public function actionDeleteFriendRequest($requestId)
{
    $friendship = Friendship::findOne($requestId);

    // Check if the current user is allowed to delete the friend request
    if ($friendship && ($friendship->user_id1 === Yii::$app->user->id || $friendship->user_id2 === Yii::$app->user->id)) {
        $friendship->delete();
        Yii::$app->session->setFlash('success', 'Friend request deleted successfully.');
    } else {
        Yii::$app->session->setFlash('error', 'You are not allowed to delete this friend request.');
    }

    // Redirect back to the same page
    return $this->redirect(Yii::$app->request->referrer);
}

}
