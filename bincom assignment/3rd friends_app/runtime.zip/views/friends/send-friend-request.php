<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Friendship */
/* @var $form yii\widgets\ActiveForm */

$this->title = 'Send Friend Request';
$this->params['breadcrumbs'][] = ['label' => 'Friends', 'url' => ['view-friends']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="friendship-send-friend-request">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'recipientId')->hiddenInput(['value' => $recipientId])->label(false) ?>

    <div class="form-group">
        <?= Html::submitButton('Send Friend Request', ['class' => 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
