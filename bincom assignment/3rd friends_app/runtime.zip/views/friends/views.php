<?php

use yii\helpers\Html;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $acceptedRequests array */
/* @var $pendingRequests array */

$this->title = 'My Friends';
$this->registerCssFile('@web/css/styles.css'); // Add this line to include the CSS file
?>

<div class="friends-views">
    <h1><?= Html::encode($this->title) ?></h1>

    <h2>Accepted Friend Requests</h2>
    <?php if (empty($acceptedRequests)): ?>
        <p>No accepted friend requests yet.</p>
    <?php else: ?>
        <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($acceptedRequests as $friendship): ?>
                    <?php $friend = $friendship->user1->id === Yii::$app->user->id ? $friendship->user2 : $friendship->user1; ?>
                    <tr>
                        <td><?= Html::encode($friend->username) ?></td>
                        <td><?= Html::encode($friend->email) ?></td>
                        <td>
                        <?= Html::a('Reject', ['reject-accepted-friend', 'requestId' => $friendship->id], ['class' => 'btn btn-danger']) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    </div>

    <h2>Pending Friend Requests</h2>
<?php if (empty($pendingRequests)): ?>
    <p>No pending friend requests.</p>
<?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pendingRequests as $friendship): ?>
                    <?php $friend = $friendship->user1; ?>
                    <tr>
                        <td><?= Html::encode($friend->username) ?></td>
                        <td><?= Html::encode($friend->email) ?></td>
                        <td>
                            <?= Html::a('Delete', ['friends/delete-friend-request', 'requestId' => $friendship->id], ['class' => 'btn btn-danger']) ?>
                            <?= Html::a('Accept', ['friends/accept-friend-request', 'requestId' => $friendship->id], ['class' => 'btn btn-success']) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

</div>
