<?php


use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $users array */

$this->title = 'All Users';
$this->registerCssFile('@web/css/styles.css'); // Add this line to include the CSS file
?>

<div class="all-users">
    <h1><?= Html::encode($this->title) ?></h1>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= Html::encode($user->username) ?></td>
                    <td><?= Html::encode($user->email) ?></td>
                    <td>
                        <?= Html::a('Send Friend Request', ['send-friend-request', 'recipientId' => $user->id], ['class' => 'btn btn-primary']) ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
