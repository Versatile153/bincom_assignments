<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Friendship */
/* @var $form yii\widgets\ActiveForm */

$this->title = 'Accept Friend Request';
$this->params['breadcrumbs'][] = ['label' => 'Friends', 'url' => ['view-friends']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="friendship-accept-friend-request">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'requestId')->hiddenInput(['value' => $requestId])->label(false) ?>

    <div class="form-group">
        <?= Html::submitButton('Accept Friend Request', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
